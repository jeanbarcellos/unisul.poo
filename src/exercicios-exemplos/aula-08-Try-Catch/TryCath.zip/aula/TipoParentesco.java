package br.unisul.aula;

public enum TipoParentesco {
	Filho, Filha, Esposo, Esposa, Pai, M�e;
}
